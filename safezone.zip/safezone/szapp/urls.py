from django.contrib import admin
from django.urls import path
from .import views

urlpatterns = [
    path('login',views.login_page,name='login'),
    path('logout',views.logout_page,name='logout'),
    path('register',views.register,name='register'),
    path('',views.home,name="home"),
    path('category',views.category,name="category"),
    path('category/<str:name>',views.colview,name="category"),
    path('category/<str:cname>/<str:pname>',views.prodetails,name="prodetails"),
    path('about',views.about,name="about"),
    path('contact',views.contact,name="contact"),
    path('cart',views.cart,name="cart"),
    path('remove_cart/<str:cid>',views.remove_cart,name="remove_cart"),
    path('fav',views.fav,name="fav"),
    path('favview',views.favview,name="favview"),
    path('remove_fat/<str:fid>',views.remove_fav,name="remove_fav"),
    path('addtocart',views.add_to_cart,name="addtocart"),
    path('productform',views.productform,name="productform"),
    path('adminsz',views.adminsz,name="adminsz"),
    path('delete/<int:idd>/',views.delete, name='delete'),
    path('update/<int:idd>/',views.update, name='update'),
]